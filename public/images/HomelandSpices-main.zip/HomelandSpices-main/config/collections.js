module.exports = {
  USER_COLLECTION: "user",
  CART_COLLECTION: "cart",
  ORDER_COLLECTION: "order",
  ADDRESS_COLLECTION: "address",
  WISHLIST_COLLECTION: "wishlist",
  PRODUCT_COLLECTION: "products",
  BANNER_COLLECTION: "banner",
  CATEGORIES_COLLECTION: "categories",
  ADMIN_CREDENTIALS: "adminCredentials",
};
